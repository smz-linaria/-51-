#ifndef __SERIAL_H__
#define __SERIAL_H__

#include <REG52.H>

/************************ 配置区 ************************/
#define BAUD_RATE 9600     // 9600/19200/38400（11.0592MHz零误差）
#define UART_BUF_SIZE 32   // 接收缓冲区大小
/********************************************************/

/**
 * @brief  串口初始化（定时器1模式2，8位自动重装）
 */
void SERIAL_Init(void);

/**
 * @brief  发送单个原始HEX字节（电脑选HEX接收）
 * @param  dat: 0x00~0xFF
 */
void SERIAL_SendByte(unsigned char dat);

/**
 * @brief  发送原始HEX字节数组（电脑选HEX接收）
 * @param  buf: 数组指针
 * @param  len: 数组长度
 */
void SERIAL_SendHexArrayRaw(unsigned char *buf, unsigned char len);

/**
 * @brief  发送单个字节的HEX格式字符串（显示为0xXX）
 * @param  dat: 0x00~0xFF
 */
void SERIAL_SendHexByte(unsigned char dat);

/**
 * @brief  发送字节数组的HEX格式字符串（带空格分隔）
 * @param  buf: 数组指针
 * @param  len: 数组长度
 */
void SERIAL_SendHexArray(unsigned char *buf, unsigned char len);

/**
 * @brief  发送字符串（文本模式）
 * @param  str: 字符串指针
 */
void SERIAL_SendString(unsigned char *str);

/**
 * @brief  发送字符串+自动换行
 * @param  str: 字符串指针
 */
void SERIAL_SendLine(unsigned char *str);

/**
 * @brief  检查是否有HEX数据可读
 * @retval 1=有数据，0=无数据
 */
bit SERIAL_Available(void);

/**
 * @brief  读取单个原始HEX字节
 * @retval 0x00~0xFF，无数据返回0xFF
 */
unsigned char SERIAL_ReadByte(void);

/**
 * @brief  清空接收缓冲区
 */
void SERIAL_ClearBuffer(void);

#endif